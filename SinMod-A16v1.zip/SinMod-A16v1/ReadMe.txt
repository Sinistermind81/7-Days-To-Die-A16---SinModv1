Hello Survivor,

To install SinMod follow these simple steps.

Steps
1. Since you're reading this that means you have downloaded it already Awesome!!!!
2. Open up your Steam program and go to "Library".
3. Find your game "7 Days to Die" and right click and go to "Properties".
4. Go to the "Local Files" tab and select "Browse Local Files..."
5. Now if you do not have a "Mods" folder Drag and drop the one from your download, if you do have a "Mods" folder open it up and delete SinMod if you have previously had it and drag and drop the new one inside the folder.
6. Now go back to the game directory and open the "Data" folder and then open the "Config" folder, grab the 2 files from the download and drag and drop them into the "Config" folder and replace or overwrite and now you have installed SinMod!!!

See you at the End of the World!!!!
~SinisterMind81
